package pkgMisc;

public class Locations {
    public static final double VILLACH_LONG = 46.6086;
    public static final double VILLACH_LAT = 13.8506;

    public static final double KLAGENFURT_LONG = 46.6365;
    public static final double KLAGENFURT_LAT = 14.3122;

    public static final double WIEN_LONG = 48.2082;
    public static final double WIEN_LAT = 16.3719;
}
