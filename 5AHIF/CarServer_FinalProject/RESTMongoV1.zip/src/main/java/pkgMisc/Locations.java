package pkgMisc;

public class Locations {
    public static final double VILLACH_FIRST = 46.6086;
    public static final double VILLACH_SECOND = 13.8506;
}
