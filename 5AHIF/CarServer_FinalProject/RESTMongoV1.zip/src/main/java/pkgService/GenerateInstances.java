package pkgService;


import com.mongodb.client.model.geojson.Point;
import com.mongodb.client.model.geojson.Position;
import pkgData.Car;
import pkgData.Database;
import pkgData.GeoPosition;
import pkgData.PetrolStation;
import pkgMisc.Locations.*;

import javax.enterprise.context.RequestScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;

import static pkgMisc.Locations.*;

@Path("generateInstances")
@RequestScoped
public class GenerateInstances {

    @Context
    private UriInfo context;

    public GenerateInstances() {

    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("")
    public Response generateInstances(@QueryParam("numCars") String numCarsStr, @QueryParam("numPetrolStations") String numPetrolStationsStr) {
        Response.ResponseBuilder res = Response.status(Response.Status.OK);

        int numCars = 10;
        int numPetrolStations = 3;

        try {
            if (numCarsStr != null && !numCarsStr.isEmpty()) {
                numCars = Integer.parseInt(numCarsStr);
            }
            if (numPetrolStationsStr != null && !numPetrolStationsStr.isEmpty()) {
                numPetrolStations = Integer.parseInt(numPetrolStationsStr);
            }
        } catch (Exception e) {
            e.printStackTrace();
            res = Response.status(Response.Status.BAD_REQUEST);
            return res.build();
        }

        System.out.println("/generateInstances Working!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

        try {
            Database db = Database.getInstance();

            for (int i = 0; i < numCars; i++) {
                db.insertCar(new Car(
                        "Car" + i,
                        new ArrayList<>(Arrays.asList(new GeoPosition(VILLACH_FIRST + Math.random(), VILLACH_SECOND + Math.random(), LocalDateTime.now())))
                ));
            }

            for (int i = 0; i < numPetrolStations; i++) {
                db.insertPetrolStation(new PetrolStation(
                        "PetrolStation" + i,
                        new Point(new Position(VILLACH_FIRST + Math.random(), VILLACH_SECOND + Math.random()))
                ));
            }
            res.entity("Instances generated");
        } catch (Exception e) {
            e.printStackTrace();
            res = Response.status(Response.Status.INTERNAL_SERVER_ERROR);
        }

        return res.build();
    }
}
