package pkgService;

import pkgData.Car;
import pkgData.Database;
import pkgData.GeoPosition;

import javax.enterprise.context.RequestScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.time.LocalDateTime;
import java.util.ArrayList;

import static pkgMisc.Locations.VILLACH_FIRST;
import static pkgMisc.Locations.VILLACH_SECOND;

@Path("updatePositions")
@RequestScoped
public class UpdatePositions {

    @Context
    private UriInfo context;

    public UpdatePositions() {

    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("")
    public Response updatePositions() {
        Response.ResponseBuilder res = Response.status(Response.Status.OK);

        try {
            Database db = Database.getInstance();

            ArrayList<Car> cars = db.getAllCars();
            // set 10 random positions for each car with an interval  of 1 minute
            for (Car car : cars) {
                for (int i = 0; i < 10; i++) {
                    car.getPositions().add(new GeoPosition(VILLACH_FIRST + Math.random(), VILLACH_SECOND + Math.random(), LocalDateTime.now().minusMinutes(i)));
                }
                db.updateCar(car);
            }

//            new Thread(new Runnable() {
//                @Override
//                public void run() {
//                    // Update every car position every second
//                    while (true) {
//                        try {
//                            Thread.sleep(1000);
//                            ArrayList<Car> cars = db.getAllCars();
//                            for (Car car : cars) {
//                                car.getPositions().add(new GeoPosition(VILLACH_FIRST + Math.random(), VILLACH_SECOND + Math.random(), LocalDateTime.now()));
//                                db.updateCar(car);
//                            }
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
//                    }
//                }
//            }).start();

        } catch (Exception e) {
            e.printStackTrace();
            res = Response.status(Response.Status.INTERNAL_SERVER_ERROR);
        }

        return res.build();
    }
}
