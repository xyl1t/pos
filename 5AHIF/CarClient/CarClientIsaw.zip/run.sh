mvn clean javafx:run > /dev/null 2> /dev/null
