package pkgMisc;
public interface Routes {
    public final String BOOKS = "books/";
    public final String CARS = "cars/";
    public final String PETROL_STATIONS = "petrolstations/";
}
